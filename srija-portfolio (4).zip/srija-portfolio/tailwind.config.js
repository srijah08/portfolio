/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['Space Grotesk', 'sans-serif'],
        body: ['Inter', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
      colors: {
        void: '#05070D',
        panel: '#0E1420',
        signal: '#9FE6FF',
        circuit: '#7C5CFF',
        hairline: '#3A4150',
      },
    },
  },
  plugins: [],
};
