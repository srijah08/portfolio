import { useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import FadeIn from './FadeIn';
import LiveProjectButton from './LiveProjectButton';

interface ProjectData {
  number: string;
  category: string;
  name: string;
  liveUrl: string;
  col1Image1: string;
  col1Image2: string;
  col2Image: string;
}

const PROJECTS: ProjectData[] = [
  {
    number: '01',
    category: 'Live Project · Web App',
    name: 'Matrix Application',
    liveUrl: 'https://matrixapp.in/login',
    col1Image1: '/matrix-login.png',
    col1Image2: '/matrix-login.png',
    col2Image: '/matrix-login.png',
  },
  {
    number: '02',
    category: 'Published Paper · IEEE',
    name: 'Disease Diagnostics — Arecanut Farming',
    liveUrl: 'https://ieeexplore.ieee.org/document/10940189',
    col1Image1: '/arecanut-paper.jpeg',
    col1Image2: '/arecanut-ieee-listing.jpeg',
    col2Image: '/arecanut-paper.jpeg',
  },
];

interface ProjectCardProps {
  project: ProjectData;
  index: number;
  total: number;
  containerRef: React.RefObject<HTMLDivElement>;
}

const ProjectCard = ({ project, index, total, containerRef }: ProjectCardProps) => {
  const cardRef = useRef<HTMLDivElement>(null);

  // Scroll progress for THIS card relative to the whole projects scroll range.
  const { scrollYProgress } = useScroll({
    target: cardRef,
    offset: ['start end', 'start start'],
  });

  // Cards further down the stack stay full-size; earlier cards scale DOWN
  // as later cards stack on top of them.
  const targetScale = 1 - (total - 1 - index) * 0.03;
  const scale = useTransform(scrollYProgress, [0, 1], [1, targetScale]);

  return (
    <div
      ref={cardRef}
      className="sticky top-24 md:top-32 h-[85vh] w-full"
      style={{ top: `${96 + index * 28}px` }}
    >
      <motion.article
        style={{ scale }}
        className="project-card group origin-top mx-auto h-full w-full flex flex-col gap-4 sm:gap-6 md:gap-8 rounded-[32px] sm:rounded-[40px] md:rounded-[48px] border border-signal/20 bg-panel/70 p-4 sm:p-6 md:p-8 transition-all duration-500 hover:border-signal/45"
      >
          <span className="project-corner project-corner-tl" />
          <span className="project-corner project-corner-br" />

          {/* Top row: number + meta + button */}
                  <div className="relative z-10 flex flex-col sm:flex-row items-start sm:justify-between gap-4 sm:gap-6">
                    <div className="flex flex-row items-start gap-3 sm:gap-6 md:gap-10 min-w-0 w-full">
                      <div
                        className="shrink-0 font-display font-semibold text-signal/30 leading-none"
                        style={{ fontSize: 'clamp(2.5rem, 10vw, 140px)' }}
                      >
                        {project.number}
                      </div>

                      <div className="flex flex-col gap-1 sm:gap-3 pt-1 sm:pt-3 md:pt-4 min-w-0 flex-1">
                        <span
                          className="font-mono uppercase tracking-widest text-signal/60"
                          style={{ fontSize: 'clamp(0.6rem, 1.1vw, 0.85rem)' }}
                        >
                          {project.category}
                        </span>
                        <h3
                          className="font-display font-medium uppercase text-[#EAF4FF] leading-tight"
                          style={{ fontSize: 'clamp(1.1rem, 2.2vw, 2.1rem)' }}
                        >
                          {project.name}
                        </h3>
                      </div>
                    </div>

                    <div className="shrink-0 self-start sm:self-auto pt-1 sm:pt-2 md:pt-3 w-full sm:w-auto">
                      {project.liveUrl && project.liveUrl !== '#' ? (
                        <LiveProjectButton href={project.liveUrl} className="w-full sm:w-auto" />
                      ) : (
                        <span className="inline-flex items-center justify-center rounded-md border border-signal/25 px-8 py-3 sm:px-10 sm:py-3.5 font-mono text-xs sm:text-sm font-medium uppercase tracking-widest text-signal/50 whitespace-nowrap">
                          Details soon
                        </span>
                      )}
                    </div>
                  </div>

        {/* Bottom row: two-column image grid */}
        <div className="relative z-10 grid grid-cols-[40%_60%] gap-3 sm:gap-4 md:gap-5 flex-1 min-h-0">
          {/* Left column - 2 stacked */}
          <div className="flex flex-col gap-3 sm:gap-4 md:gap-5 min-h-0">
            <div
              className="overflow-hidden rounded-[24px] sm:rounded-[30px] md:rounded-[36px] border border-signal/10"
              style={{ height: 'clamp(130px, 16vw, 230px)' }}
            >
              <img
                src={project.col1Image1}
                alt={`${project.name} preview 1`}
                className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                loading="lazy"
                draggable={false}
              />
            </div>
            <div
              className="overflow-hidden rounded-[24px] sm:rounded-[30px] md:rounded-[36px] border border-signal/10"
              style={{ height: 'clamp(160px, 22vw, 340px)' }}
            >
              <img
                src={project.col1Image2}
                alt={`${project.name} preview 2`}
                className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                loading="lazy"
                draggable={false}
              />
            </div>
          </div>

          {/* Right column - 1 tall */}
          <div className="overflow-hidden rounded-[24px] sm:rounded-[30px] md:rounded-[36px] border border-signal/10 min-h-0">
            <img
              src={project.col2Image}
              alt={`${project.name} preview 3`}
              className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
              loading="lazy"
              draggable={false}
            />
          </div>
        </div>
      </motion.article>
    </div>
  );
};

const ProjectsSection = () => {
  const containerRef = useRef<HTMLDivElement>(null);

  return (
    <section
      id="projects"
      className="relative z-10 w-full bg-void px-4 sm:px-6 md:px-10 pt-20 sm:pt-24 md:pt-32 pb-24 font-display overflow-hidden"
    >
      <div className="absolute inset-0 projects-grid opacity-[0.04] pointer-events-none" />

      <FadeIn y={40}>
        <p className="text-center font-mono text-[10px] sm:text-xs uppercase tracking-[0.35em] text-signal/70 mb-3">
          04 / Build Log
        </p>
        <h2
          className="text-center font-semibold uppercase tracking-tight leading-none mb-16 sm:mb-20 md:mb-28 text-[#EAF4FF]"
          style={{ fontSize: 'clamp(3rem, 12vw, 160px)' }}
        >
          Projects
        </h2>
      </FadeIn>

      <div ref={containerRef} className="relative z-10 mx-auto max-w-7xl">
        {PROJECTS.map((project, i) => (
          <ProjectCard
            key={project.number}
            project={project}
            index={i}
            total={PROJECTS.length}
            containerRef={containerRef}
          />
        ))}
      </div>

      <style>{`
        .projects-grid {
          background-image:
            linear-gradient(rgba(159, 230, 255, 0.5) 1px, transparent 1px),
            linear-gradient(90deg, rgba(159, 230, 255, 0.5) 1px, transparent 1px);
          background-size: 56px 56px;
        }
        .project-card:hover {
          box-shadow: 0 0 60px rgba(159, 230, 255, 0.12);
        }
        .project-corner {
          position: absolute;
          width: 18px;
          height: 18px;
          border-color: rgba(159, 230, 255, 0.45);
          opacity: 0;
          transition: opacity 0.3s;
          z-index: 5;
        }
        .project-card:hover .project-corner { opacity: 1; }
        .project-corner-tl { top: 14px; left: 14px; border-top: 1.5px solid; border-left: 1.5px solid; }
        .project-corner-br { bottom: 14px; right: 14px; border-bottom: 1.5px solid; border-right: 1.5px solid; }
      `}</style>
    </section>
  );
};

export default ProjectsSection;
