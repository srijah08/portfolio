import FadeIn from './FadeIn';

const EXPERIENCE = [
  {
    title: 'Application Developer (Live Project)',
    org: 'GBPL — State Election Commission of Karnataka',
    period: 'Sept 2025 – April 2026',
    description:
      'Designed and developed the Matrix Application, a web-based electoral management system handling voter and elector data at scale across multiple constituencies. Deployed and maintained the live production system actively used in state election workflows, ensuring uptime and data accuracy.',
  },
  {
    title: 'Intern — Electronics Manufacturing',
    org: 'Foxconn (BiSafe Project), Devanahalli',
    period: 'Feb 2025 – Aug 2025',
    description:
      'Contributed to system integration and QA processes in large-scale industrial electronics manufacturing.',
  },
  {
    title: 'Student Intern',
    org: 'DRDL — DRDO, Pune',
    period: 'Sep 2022 – Oct 2023',
    description:
      'Researched crypto mining optimization using parallel computing and immersion cooling, implementing hardware-level efficiency improvements.',
  },
];

const ExperienceSection = () => {
  return (
    <section
      id="experience"
      className="relative w-full bg-void px-5 sm:px-8 md:px-10 py-20 sm:py-24 md:py-32 font-display overflow-hidden"
    >
      <div className="absolute inset-0 about-grid-exp opacity-[0.04] pointer-events-none" />

      <FadeIn y={40}>
        <p className="text-center font-mono text-[10px] sm:text-xs uppercase tracking-[0.35em] text-signal/70 mb-3">
          02 / Timeline
        </p>
        <h2
          className="text-center font-semibold uppercase text-[#EAF4FF] mb-16 sm:mb-20 md:mb-28 leading-none"
          style={{ fontSize: 'clamp(3rem, 12vw, 160px)' }}
        >
          Experience
        </h2>
      </FadeIn>

      <div className="relative mx-auto max-w-5xl">
        {/* circuit trace vertical line */}
        <div className="exp-trace absolute left-[10px] sm:left-[14px] top-2 bottom-2 w-px" />

        {EXPERIENCE.map((role, i) => (
          <FadeIn key={role.org} delay={i * 0.12} y={30}>
            <div className="relative flex flex-row items-start gap-6 sm:gap-10 md:gap-14 py-8 sm:py-10 md:py-12 pl-8 sm:pl-10">
              {/* node */}
              <span className="exp-node absolute left-0 top-[14px] sm:top-[18px]" />

              <div className="group flex flex-col gap-2 sm:gap-3 md:gap-4">
                <div className="flex flex-col sm:flex-row sm:items-baseline sm:justify-between sm:gap-6">
                  <h3
                    className="font-medium uppercase text-[#EAF4FF] leading-tight relative inline-block w-fit"
                    style={{ fontSize: 'clamp(1rem, 2.2vw, 2.1rem)' }}
                  >
                    {role.title}
                    <span className="absolute left-0 -bottom-1 h-px w-0 bg-signal/70 transition-all duration-500 group-hover:w-full" />
                  </h3>
                  <span className="font-mono text-[10px] sm:text-xs text-signal/60 shrink-0 uppercase tracking-widest">
                    {role.period}
                  </span>
                </div>
                <span className="font-mono text-[11px] sm:text-sm text-[#9fb3cc] uppercase tracking-widest">
                  {role.org}
                </span>
                <p
                  className="font-body leading-relaxed text-[#c7d6e8] max-w-3xl mt-1"
                  style={{ fontSize: 'clamp(0.85rem, 1.6vw, 1.2rem)' }}
                >
                  {role.description}
                </p>
              </div>
            </div>
          </FadeIn>
        ))}
      </div>

      <style>{`
        .about-grid-exp {
          background-image:
            linear-gradient(rgba(159, 230, 255, 0.5) 1px, transparent 1px),
            linear-gradient(90deg, rgba(159, 230, 255, 0.5) 1px, transparent 1px);
          background-size: 56px 56px;
        }
        .exp-trace {
          background: linear-gradient(to bottom, rgba(159,230,255,0.05), rgba(159,230,255,0.4), rgba(159,230,255,0.05));
        }
        .exp-node {
          width: 12px;
          height: 12px;
          border-radius: 50%;
          background: #05070D;
          border: 2px solid #9fe6ff;
          box-shadow: 0 0 10px rgba(159, 230, 255, 0.7);
          animation: expNodePulse 2.4s ease-in-out infinite;
        }
        @keyframes expNodePulse {
          0%, 100% { box-shadow: 0 0 6px rgba(159, 230, 255, 0.4); }
          50% { box-shadow: 0 0 14px rgba(159, 230, 255, 0.9); }
        }
      `}</style>
    </section>
  );
};

export default ExperienceSection;
