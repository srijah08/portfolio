import { Mail, Phone, Linkedin, MapPin, ArrowUpRight } from 'lucide-react';
import FadeIn from './FadeIn';

interface ContactMethod {
  icon: typeof Mail;
  label: string;
  value: string;
  href: string;
}

const CONTACT_METHODS: ContactMethod[] = [
  {
    icon: Mail,
    label: 'Email',
    value: 'srijabsncec@gmail.com',
    href: 'mailto:srijabsncec@gmail.com',
  },
  {
    icon: Phone,
    label: 'Phone',
    value: '+91 72598 79875',
    href: 'tel:+917259879875',
  },
  {
    icon: Linkedin,
    label: 'LinkedIn',
    value: 'in/srija-b-s-300914233',
    href: 'https://www.linkedin.com/in/srija-b-s-300914233',
  },
  {
    icon: MapPin,
    label: 'Location',
    value: 'Bangalore, Karnataka',
    href: 'https://www.google.com/maps/place/Bangalore',
  },
];

const ContactSection = () => {
  return (
    <section
      id="contact"
      className="relative w-full bg-void px-5 sm:px-8 md:px-10 pt-24 sm:pt-28 md:pt-32 pb-16 sm:pb-20 font-display overflow-hidden"
    >
      <div className="absolute inset-0 contact-grid opacity-[0.05] pointer-events-none" />
      <div className="absolute left-1/2 -translate-x-1/2 top-[8%] h-72 w-72 rounded-full contact-glow blur-3xl pointer-events-none" />

      {/* Heading */}
      <FadeIn y={40}>
        <p className="text-center font-mono text-[10px] sm:text-xs uppercase tracking-[0.35em] text-signal/70 mb-3">
          06 / Connect
        </p>
        <h2
          className="hero-heading text-center font-semibold uppercase tracking-tight leading-none mb-4"
          style={{ fontSize: 'clamp(3rem, 12vw, 160px)' }}
        >
          Get in touch
        </h2>
      </FadeIn>

      <FadeIn delay={0.15} y={20}>
        <p
          className="text-center font-mono uppercase tracking-widest text-[#9fb3cc] mb-12 sm:mb-16 md:mb-20"
          style={{ fontSize: 'clamp(0.75rem, 1.2vw, 1rem)' }}
        >
          Pick whichever channel suits you
        </p>
      </FadeIn>

      {/* Contact cards */}
          <div className="relative z-10 mx-auto grid max-w-5xl grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5 md:gap-6">
        {CONTACT_METHODS.map((method, i) => {
          const Icon = method.icon;
          const isExternal = method.href.startsWith('http');

          return (
            <FadeIn key={method.label} delay={i * 0.1} y={30}>
              <a
                href={method.href}
                target={isExternal ? '_blank' : undefined}
                rel={isExternal ? 'noopener noreferrer' : undefined}
                className="contact-card group relative flex h-full flex-col justify-between gap-8 sm:gap-10 rounded-2xl border border-signal/20 bg-panel/60 p-6 sm:p-7 md:p-8 transition-all duration-300 hover:border-signal/55 hover:-translate-y-1"
              >
                <span className="contact-corner contact-corner-tl" />
                <span className="contact-corner contact-corner-br" />

                <div className="relative z-10 flex items-start justify-between">
                  <div className="rounded-lg border border-signal/25 p-3 sm:p-3.5 transition-colors duration-300 group-hover:border-signal/60">
                    <Icon
                      className="text-signal"
                      size={22}
                      strokeWidth={1.5}
                    />
                  </div>
                  <ArrowUpRight
                    className="text-[#9fb3cc] transition-all duration-300 group-hover:text-signal group-hover:rotate-12"
                    size={22}
                    strokeWidth={1.5}
                  />
                </div>

                <div className="relative z-10 flex flex-col gap-2 sm:gap-3">
                  <span
                    className="font-mono uppercase tracking-widest text-signal/60"
                    style={{ fontSize: 'clamp(0.65rem, 1.05vw, 0.85rem)' }}
                  >
                    {method.label}
                  </span>
                  <span
                    className="font-display font-medium text-[#EAF4FF] [overflow-wrap:anywhere] break-normal"
                    style={{ fontSize: 'clamp(1rem, 1.8vw, 1.4rem)' }}
                  >
                    {method.value}
                  </span>
                </div>
              </a>
            </FadeIn>
          );
        })}
      </div>

      {/* Footer line */}
      <FadeIn delay={0.4} y={20}>
        <div className="relative z-10 mx-auto mt-20 sm:mt-24 md:mt-28 flex max-w-5xl flex-col items-center gap-3 border-t border-signal/10 pt-8 text-center sm:flex-row sm:justify-between">
          <span
            className="font-mono uppercase tracking-widest text-[#9fb3cc]"
            style={{ fontSize: 'clamp(0.65rem, 1.05vw, 0.85rem)' }}
          >
            © 2026 Srija B S
          </span>
          <span
            className="font-mono uppercase tracking-widest text-[#9fb3cc]"
            style={{ fontSize: 'clamp(0.65rem, 1.05vw, 0.85rem)' }}
          >
            Designed & built in Bangalore
          </span>
        </div>
      </FadeIn>

      <style>{`
        .contact-grid {
          background-image:
            linear-gradient(rgba(159, 230, 255, 0.5) 1px, transparent 1px),
            linear-gradient(90deg, rgba(159, 230, 255, 0.5) 1px, transparent 1px);
          background-size: 56px 56px;
        }
        .contact-glow {
          background: radial-gradient(circle, rgba(159, 230, 255, 0.15), transparent 70%);
        }
        .contact-card:hover {
          box-shadow: 0 0 40px rgba(159, 230, 255, 0.1);
        }
        .contact-corner {
          position: absolute;
          width: 14px;
          height: 14px;
          border-color: rgba(159, 230, 255, 0.4);
          opacity: 0;
          transition: opacity 0.3s;
          z-index: 5;
        }
        .contact-card:hover .contact-corner { opacity: 1; }
        .contact-corner-tl { top: 10px; left: 10px; border-top: 1.5px solid; border-left: 1.5px solid; }
        .contact-corner-br { bottom: 10px; right: 10px; border-bottom: 1.5px solid; border-right: 1.5px solid; }
      `}</style>
    </section>
  );
};

export default ContactSection;
