import { Trophy, Medal, Award, FileBadge, Sparkles } from 'lucide-react';
import FadeIn from './FadeIn';

const ACHIEVEMENTS = [
  {
    title: '1st Prize',
    org: 'Cirrus Labs HackLab',
    icon: Trophy,
  },
  {
    title: 'State Champion',
    org: 'NASA Space Apps Challenge',
    icon: Sparkles,
  },
  {
    title: '1st Runner-up',
    org: 'Bull and Code, IIT Bombay',
    icon: Medal,
  },
  {
    title: '1st Prize',
    org: 'Final Year Project Exhibition',
    icon: Award,
  },
  {
    title: '1st Position',
    org: 'Technical Paper Presentation, NCET',
    icon: FileBadge,
  },
];

const EXTRACURRICULAR = [
  { label: 'State-level', value: 'Football' },
  { label: 'National-level', value: 'Rock Climbing' },
];

const AchievementsSection = () => {
  return (
    <section
      id="achievements"
      className="relative w-full bg-void px-5 sm:px-8 md:px-10 py-20 sm:py-24 md:py-32 font-display overflow-hidden"
    >
      <div className="absolute inset-0 ach-grid opacity-[0.04] pointer-events-none" />
      <div className="absolute right-[10%] top-[15%] h-72 w-72 rounded-full ach-glow blur-3xl pointer-events-none" />

      <FadeIn y={40}>
        <p className="text-center font-mono text-[10px] sm:text-xs uppercase tracking-[0.35em] text-signal/70 mb-3">
          05 / Recognition
        </p>
        <h2
          className="text-center font-semibold uppercase text-[#EAF4FF] mb-14 sm:mb-16 md:mb-20 leading-none"
          style={{ fontSize: 'clamp(3rem, 12vw, 160px)' }}
        >
          Achievements
        </h2>
      </FadeIn>

      <div className="relative z-10 mx-auto max-w-5xl">
        {/* Achievement cards grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5 md:gap-6">
          {ACHIEVEMENTS.map((item, i) => {
            const Icon = item.icon;
            return (
              <FadeIn key={item.org} delay={i * 0.08} y={24}>
                <div
                  className="achievement-card group relative h-full overflow-hidden rounded-xl border border-signal/15 bg-panel/60 px-6 sm:px-7 py-7 sm:py-8 transition-all duration-300 hover:-translate-y-2 hover:border-signal/45"
                >
                  <span className="ach-corner ach-corner-tl" />
                  <span className="ach-corner ach-corner-br" />

                  {/* glow on hover */}
                  <div
                    className="pointer-events-none absolute -right-8 -top-8 h-28 w-28 rounded-full opacity-0 blur-2xl transition-opacity duration-500 group-hover:opacity-60"
                    style={{ background: 'radial-gradient(circle, #9fe6ff, transparent)' }}
                  />

                  <div className="relative z-10 flex items-start justify-between">
                    <p
                      className="font-semibold uppercase text-[#EAF4FF] leading-none"
                      style={{ fontSize: 'clamp(1.2rem, 2.2vw, 1.7rem)' }}
                    >
                      {item.title}
                    </p>
                    <Icon
                      className="h-6 w-6 sm:h-7 sm:w-7 text-signal/80 shrink-0 transition-transform duration-500 group-hover:scale-110 group-hover:rotate-6"
                      strokeWidth={1.6}
                    />
                  </div>
                  <p
                    className="relative z-10 mt-3 font-mono uppercase tracking-widest text-[#9fb3cc]"
                    style={{ fontSize: 'clamp(0.65rem, 1.05vw, 0.8rem)' }}
                  >
                    {item.org}
                  </p>
                </div>
              </FadeIn>
            );
          })}
        </div>

        {/* Extracurricular strip */}
        <FadeIn delay={0.4} y={24}>
          <div
            className="mt-12 sm:mt-14 md:mt-16 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6 sm:gap-10 py-8 sm:py-10 px-6 sm:px-8 rounded-xl border border-signal/15 bg-panel/40"
          >
            <span
              className="font-mono uppercase tracking-widest text-signal/60 shrink-0"
              style={{ fontSize: 'clamp(0.65rem, 1.1vw, 0.85rem)' }}
            >
              Extracurricular
            </span>

            <div className="flex flex-col sm:flex-row gap-5 sm:gap-12 w-full sm:w-auto">
              {EXTRACURRICULAR.map((item) => (
                <div key={item.label} className="flex items-baseline gap-3">
                  <span
                    className="font-mono uppercase tracking-widest text-[#9fb3cc]"
                    style={{ fontSize: 'clamp(0.6rem, 0.95vw, 0.75rem)' }}
                  >
                    {item.label}
                  </span>
                  <span
                    className="font-display font-medium uppercase text-[#EAF4FF]"
                    style={{ fontSize: 'clamp(0.9rem, 1.6vw, 1.2rem)' }}
                  >
                    {item.value}
                  </span>
                </div>
              ))}
            </div>

            <span
              className="font-body text-[#9fb3cc] leading-relaxed max-w-md"
              style={{ fontSize: 'clamp(0.75rem, 1.2vw, 0.95rem)' }}
            >
              Active in Bizothon, Ideathon, Hacklab, IdeaStorm, and inter-college hackathons.
            </span>
          </div>
        </FadeIn>
      </div>

      <style>{`
        .ach-grid {
          background-image:
            linear-gradient(rgba(159, 230, 255, 0.5) 1px, transparent 1px),
            linear-gradient(90deg, rgba(159, 230, 255, 0.5) 1px, transparent 1px);
          background-size: 56px 56px;
        }
        .ach-glow {
          background: radial-gradient(circle, rgba(124, 92, 255, 0.18), transparent 70%);
        }
        .ach-corner {
          position: absolute;
          width: 14px;
          height: 14px;
          border-color: rgba(159, 230, 255, 0.4);
          opacity: 0;
          transition: opacity 0.3s;
        }
        .achievement-card:hover .ach-corner { opacity: 1; }
        .ach-corner-tl { top: 8px; left: 8px; border-top: 1.5px solid; border-left: 1.5px solid; }
        .ach-corner-br { bottom: 8px; right: 8px; border-bottom: 1.5px solid; border-right: 1.5px solid; }
      `}</style>
    </section>
  );
};

export default AchievementsSection;
