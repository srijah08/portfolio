import { useEffect, useRef, useState } from 'react';
import FadeIn from './FadeIn';
import AIAvatar from './AIAvatar';

const NAV_LINKS = [
  { label: 'About', href: '#about' },
  { label: 'Projects', href: '#projects' },
  { label: 'Achievements', href: '#achievements' },
  { label: 'Contact', href: '#contact' },
];

const TYPED_LINE = '> initializing srija.dev ...';

const HeroSection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const [typed, setTyped] = useState('');

  // Typed terminal-line effect on mount
  useEffect(() => {
    let i = 0;
    const interval = setInterval(() => {
      i += 1;
      setTyped(TYPED_LINE.slice(0, i));
      if (i >= TYPED_LINE.length) clearInterval(interval);
    }, 35);
    return () => clearInterval(interval);
  }, []);

  // Snap-scroll: one wheel tick / keypress while at top → jump to About
  useEffect(() => {
    let fired = false;

    const goToAbout = () => {
      if (fired) return;
      fired = true;
      const about = document.getElementById('about');
      if (about) about.scrollIntoView({ behavior: 'auto', block: 'start' });
    };

    const onWheel = (e: WheelEvent) => {
      if (fired) return;
      if (e.deltaY <= 0) return;
      if (window.scrollY > 50) return;
      e.preventDefault();
      goToAbout();
    };

    const onKey = (e: KeyboardEvent) => {
      if (fired) return;
      if (window.scrollY > 50) return;
      if (e.key === 'ArrowDown' || e.key === 'PageDown' || e.key === ' ') {
        e.preventDefault();
        goToAbout();
      }
    };

    window.addEventListener('wheel', onWheel, { passive: false });
    window.addEventListener('keydown', onKey);
    return () => {
      window.removeEventListener('wheel', onWheel);
      window.removeEventListener('keydown', onKey);
    };
  }, []);

  return (
    <section ref={sectionRef} className="relative h-screen w-full overflow-hidden bg-void font-display">
      {/* Ambient animated background: grid + glow + particles */}
      <div className="absolute inset-0 hero-grid opacity-[0.09]" />
      <div className="absolute -left-32 top-1/4 h-[420px] w-[420px] rounded-full hero-glow-1 blur-3xl" />
      <div className="absolute left-1/4 bottom-0 h-[320px] w-[320px] rounded-full hero-glow-2 blur-3xl" />
      <div className="absolute inset-0 pointer-events-none">
        {[...Array(16)].map((_, i) => (
          <span
            key={i}
            className="hero-particle absolute rounded-full bg-signal"
            style={{
              left: `${(i * 37) % 60}%`,
              top: `${(i * 53) % 90}%`,
              width: `${2 + (i % 3)}px`,
              height: `${2 + (i % 3)}px`,
              opacity: 0.25 + (i % 4) * 0.08,
              animationDelay: `${i * 0.4}s`,
              animationDuration: `${6 + (i % 5)}s`,
            }}
          />
        ))}
      </div>

      {/* Photo panel, right side — HUD framed */}
      <div className="absolute inset-y-0 right-0 w-full sm:w-[55%] md:w-[48%] lg:w-[42%]">
        <div className="absolute inset-6 sm:inset-10 md:inset-12 z-20 pointer-events-none hud-frame hidden sm:block">
          <span className="hud-corner hud-corner-tl" />
          <span className="hud-corner hud-corner-tr" />
          <span className="hud-corner hud-corner-bl" />
          <span className="hud-corner hud-corner-br" />
          <div className="hud-scanline" />
        </div>
        <img
          src="/srija-hero.jpeg"
          alt="Srija B S"
          className="h-full w-full object-cover"
          style={{ objectPosition: 'center 22%', filter: 'saturate(0.92) contrast(1.05)' }}
          draggable={false}
        />
        <div className="absolute inset-0 hero-duotone" />
        {/* Left edge fade into background */}
        <div className="absolute inset-0 bg-gradient-to-r from-void via-transparent to-transparent" />
      </div>

      {/* Overlays for readability */}
      <div className="absolute inset-0 bg-gradient-to-r from-void via-void/70 sm:via-void/40 to-transparent" />
      <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-black/85" />
      <div className="absolute inset-0 sm:hidden bg-black/55" />

      {/* Content layer */}
      <div className="relative z-10 flex h-full flex-col">
        {/* Top bar */}
        <FadeIn delay={0} y={-20} className="relative">
          <div className="flex flex-wrap items-center justify-between gap-y-3 px-6 md:px-10 pt-6 md:pt-8">
            <ul className="flex items-center gap-4 sm:gap-8 md:gap-12 flex-wrap">
              {NAV_LINKS.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="font-mono text-[9px] sm:text-xs font-medium uppercase tracking-[0.15em] sm:tracking-[0.2em] text-[#9fb3cc] transition hover:text-signal"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>

            <a
              href="#contact"
              className="inline-flex items-center rounded-md border border-signal/30 bg-signal/[0.06] px-3 py-1.5 sm:px-5 sm:py-2.5 font-mono text-[9px] sm:text-xs font-medium uppercase tracking-[0.15em] sm:tracking-[0.2em] text-signal backdrop-blur-md transition hover:bg-signal/15 hover:border-signal/60 shrink-0"
            >
              Email me
            </a>
          </div>
        </FadeIn>

        {/* Middle-left: PORTFOLIO + Name + Subtitle */}
        <div className="flex flex-1 items-center">
          <div className="w-full max-w-7xl px-6 md:px-10">
            <div className="max-w-full sm:max-w-[58%] md:max-w-[55%] lg:max-w-[60%]">

            {/* Terminal typed line */}
            <p className="mb-4 font-mono text-[11px] sm:text-xs text-signal/80">
              {typed}
              <span className="terminal-cursor">_</span>
            </p>

            <FadeIn delay={0.5} y={40}>
              <h1
                className="font-display font-semibold uppercase leading-[0.88] tracking-tight text-[#EAF4FF]"
                style={{ fontSize: 'clamp(2.6rem, 9vw, 7.2rem)' }}
              >
                Srija<br />
                <span className="hero-name-accent">B S</span>
              </h1>
            </FadeIn>

            <FadeIn delay={0.85} y={20}>
              <p className="mt-5 md:mt-7 font-mono text-[10px] sm:text-xs md:text-sm font-medium uppercase tracking-[0.25em] text-[#9fb3cc]">
                <span className="text-signal">&lt;</span> Software Developer · AI/ML Enthusiast <span className="text-signal">/&gt;</span>
              </p>
            </FadeIn>
            </div>

            {/* Illustrated AI companion avatar */}
            <FadeIn delay={1.2} y={20}>
              <div className="flex items-center gap-3 mt-6 md:mt-10">
                <div className="h-14 w-14 sm:h-20 sm:w-20 md:h-24 md:w-24">
                  <AIAvatar />
                </div>
                <span className="font-mono text-[9px] sm:text-[10px] font-medium uppercase tracking-[0.2em] text-[#9fb3cc] max-w-[160px] leading-relaxed">
                  // AI co-pilot online
                </span>
              </div>
            </FadeIn>

            {/* Tech chip row */}
            <FadeIn delay={1.4} y={20}>
              <div className="flex flex-wrap gap-2 mt-5 md:mt-8">
                {['Python', 'AI/ML', 'VLSI', 'Web Dev'].map((tag) => (
                  <span
                    key={tag}
                    className="hero-chip font-mono text-[9px] sm:text-[10px] font-medium uppercase tracking-[0.1em] text-[#bcd6ee] border border-signal/20 rounded px-3 py-1.5 backdrop-blur-sm"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </FadeIn>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="flex items-end justify-between px-6 md:px-10 pb-7 sm:pb-10 md:pb-12">
          {/* Scroll indicator */}
          <FadeIn delay={1.1} y={20}>
            <a href="#about" aria-label="Scroll to next section" className="group flex flex-col items-center gap-3">
              <span className="font-mono text-[9px] sm:text-[10px] font-medium uppercase tracking-[0.3em] text-[#9fb3cc] transition group-hover:text-signal">
                Scroll
              </span>
              <div className="relative h-12 w-px overflow-hidden bg-white/15">
                <span
                  className="absolute inset-x-0 top-0 h-1/2 w-full bg-signal"
                  style={{ animation: 'scrollLine 1.8s ease-in-out infinite' }}
                />
              </div>
            </a>
          </FadeIn>

          {/* Location tag */}
          <FadeIn delay={1.1} y={20}>
            <span className="font-mono text-[10px] sm:text-xs font-medium uppercase tracking-[0.2em] text-[#9fb3cc]">
              <span className="hero-live-dot" /> Bangalore, Karnataka
            </span>
          </FadeIn>
        </div>
      </div>

      <style>{`
        @keyframes scrollLine {
          0% { transform: translateY(-100%); }
          100% { transform: translateY(200%); }
        }
        .hero-grid {
          background-image:
            linear-gradient(rgba(159, 230, 255, 0.5) 1px, transparent 1px),
            linear-gradient(90deg, rgba(159, 230, 255, 0.5) 1px, transparent 1px);
          background-size: 48px 48px;
          mask-image: radial-gradient(ellipse 70% 60% at 30% 40%, black 0%, transparent 75%);
        }
        .hero-glow-1 {
          background: radial-gradient(circle, rgba(159, 230, 255, 0.22), transparent 70%);
          animation: heroGlowDrift 14s ease-in-out infinite;
        }
        .hero-glow-2 {
          background: radial-gradient(circle, rgba(124, 92, 255, 0.18), transparent 70%);
          animation: heroGlowDrift 18s ease-in-out infinite reverse;
        }
        @keyframes heroGlowDrift {
          0%, 100% { transform: translate(0, 0) scale(1); }
          50% { transform: translate(30px, -20px) scale(1.15); }
        }
        .hero-particle {
          animation: heroParticleFloat ease-in-out infinite;
        }
        @keyframes heroParticleFloat {
          0%, 100% { transform: translateY(0) translateX(0); opacity: 0.2; }
          50% { transform: translateY(-22px) translateX(8px); opacity: 0.7; }
        }
        .hero-chip {
          background: rgba(159, 230, 255, 0.04);
          transition: background 0.3s, border-color 0.3s, transform 0.3s;
        }
        .hero-chip:hover {
          background: rgba(159, 230, 255, 0.1);
          border-color: rgba(159, 230, 255, 0.5);
          transform: translateY(-2px);
        }
        .hero-name-accent {
          background: linear-gradient(110deg, #EAF4FF 30%, #9fe6ff 50%, #EAF4FF 70%);
          background-size: 200% 100%;
          -webkit-background-clip: text;
          background-clip: text;
          color: transparent;
          animation: heroNameShimmer 5s ease-in-out infinite;
        }
        @keyframes heroNameShimmer {
          0% { background-position: 200% 0; }
          100% { background-position: -200% 0; }
        }
        .terminal-cursor {
          animation: terminalBlink 1s step-start infinite;
          color: #9fe6ff;
        }
        @keyframes terminalBlink {
          50% { opacity: 0; }
        }
        .hero-duotone {
          background: linear-gradient(160deg, rgba(124, 92, 255, 0.1), rgba(159, 230, 255, 0.06));
          mix-blend-mode: overlay;
        }
        .hud-frame { position: absolute; }
        .hud-corner {
          position: absolute;
          width: 22px;
          height: 22px;
          border-color: rgba(159, 230, 255, 0.55);
        }
        .hud-corner-tl { top: 0; left: 0; border-top: 2px solid; border-left: 2px solid; }
        .hud-corner-tr { top: 0; right: 0; border-top: 2px solid; border-right: 2px solid; }
        .hud-corner-bl { bottom: 0; left: 0; border-bottom: 2px solid; border-left: 2px solid; }
        .hud-corner-br { bottom: 0; right: 0; border-bottom: 2px solid; border-right: 2px solid; }
        .hud-scanline {
          position: absolute;
          left: 0;
          right: 0;
          height: 2px;
          background: linear-gradient(90deg, transparent, rgba(159, 230, 255, 0.6), transparent);
          animation: hudScan 5s ease-in-out infinite;
        }
        @keyframes hudScan {
          0%, 100% { top: 4%; opacity: 0; }
          10% { opacity: 0.8; }
          50% { top: 92%; opacity: 0.8; }
          60% { opacity: 0; }
        }
        .hero-live-dot {
          display: inline-block;
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: #9fe6ff;
          margin-right: 8px;
          box-shadow: 0 0 8px #9fe6ff;
          animation: heroLiveDot 2s ease-in-out infinite;
        }
        @keyframes heroLiveDot {
          0%, 100% { opacity: 0.4; }
          50% { opacity: 1; }
        }
      `}</style>
    </section>
  );
};

export default HeroSection;
