import { Cpu, Globe, CircuitBoard, Thermometer, Lightbulb } from 'lucide-react';
import FadeIn from './FadeIn';

const SERVICES = [
  {
    title: 'AI/ML Solutions',
    icon: Cpu,
    description:
      'Building CNN-based detection and prediction systems — from automated disease diagnostics to real-time prediction web apps that turn raw data into practical, usable insights.',
  },
  {
    title: 'Web Application Development',
    icon: Globe,
    description:
      'Designing and building reliable, production-grade web applications — including live electoral and data management systems handling real-world scale and accuracy requirements.',
  },
  {
    title: 'Electronics & VLSI',
    icon: CircuitBoard,
    description:
      'Strong foundation in Electronics and Communication Engineering, with hands-on exposure to VLSI design and large-scale industrial electronics manufacturing and QA.',
  },
  {
    title: 'Hardware-Level Research',
    icon: Thermometer,
    description:
      'Researching performance bottlenecks and efficiency improvements at the hardware level — from parallel computing strategies to immersion cooling for thermal optimization.',
  },
  {
    title: 'Problem Solving',
    icon: Lightbulb,
    description:
      'Quick learner with a track record across hackathons, ideathons, and technical paper presentations — comfortable adapting fast in dynamic, fast-moving environments.',
  },
];

const ServicesSection = () => {
  return (
    <section
      id="services"
      className="relative w-full bg-void px-5 sm:px-8 md:px-10 py-20 sm:py-24 md:py-32 font-display overflow-hidden"
    >
      <div className="absolute inset-0 services-grid opacity-[0.05] pointer-events-none" />
      <div className="absolute left-[8%] bottom-[10%] h-72 w-72 rounded-full services-glow blur-3xl pointer-events-none" />

      <FadeIn y={40}>
        <p className="text-center font-mono text-[10px] sm:text-xs uppercase tracking-[0.35em] text-signal/70 mb-3">
          03 / Capabilities
        </p>
        <h2
          className="text-center font-semibold uppercase text-[#EAF4FF] mb-16 sm:mb-20 md:mb-24 leading-none"
          style={{ fontSize: 'clamp(3rem, 12vw, 160px)' }}
        >
          Skills
        </h2>
      </FadeIn>

      <div className="relative z-10 mx-auto max-w-6xl grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5 md:gap-6">
        {SERVICES.map((service, i) => {
          const Icon = service.icon;
          return (
            <FadeIn key={service.title} delay={i * 0.08} y={30}>
              <div className="service-card group relative h-full overflow-hidden rounded-xl border border-signal/15 bg-panel/60 px-6 sm:px-7 py-7 sm:py-8 transition-all duration-300 hover:-translate-y-1.5 hover:border-signal/45">
                <span className="service-corner service-corner-tl" />
                <span className="service-corner service-corner-br" />

                <div
                  className="pointer-events-none absolute -right-10 -top-10 h-32 w-32 rounded-full opacity-0 blur-2xl transition-opacity duration-500 group-hover:opacity-50"
                  style={{ background: 'radial-gradient(circle, #9fe6ff, transparent)' }}
                />

                <Icon
                  className="relative z-10 h-7 w-7 sm:h-8 sm:w-8 text-signal/80 mb-5 transition-transform duration-500 group-hover:scale-110 group-hover:rotate-3"
                  strokeWidth={1.5}
                />

                <h3
                  className="relative z-10 font-medium uppercase text-[#EAF4FF] leading-tight mb-3"
                  style={{ fontSize: 'clamp(1rem, 2vw, 1.35rem)' }}
                >
                  {service.title}
                </h3>
                <p
                  className="relative z-10 font-body leading-relaxed text-[#9fb3cc]"
                  style={{ fontSize: 'clamp(0.85rem, 1.4vw, 1rem)' }}
                >
                  {service.description}
                </p>
              </div>
            </FadeIn>
          );
        })}
      </div>

      <style>{`
        .services-grid {
          background-image:
            linear-gradient(rgba(159, 230, 255, 0.5) 1px, transparent 1px),
            linear-gradient(90deg, rgba(159, 230, 255, 0.5) 1px, transparent 1px);
          background-size: 56px 56px;
        }
        .services-glow {
          background: radial-gradient(circle, rgba(124, 92, 255, 0.2), transparent 70%);
        }
        .service-corner {
          position: absolute;
          width: 14px;
          height: 14px;
          border-color: rgba(159, 230, 255, 0.4);
          opacity: 0;
          transition: opacity 0.3s;
        }
        .service-card:hover .service-corner { opacity: 1; }
        .service-corner-tl { top: 8px; left: 8px; border-top: 1.5px solid; border-left: 1.5px solid; }
        .service-corner-br { bottom: 8px; right: 8px; border-bottom: 1.5px solid; border-right: 1.5px solid; }
      `}</style>
    </section>
  );
};

export default ServicesSection;
