import { useEffect, useState } from 'react';

/**
 * AIAvatar — a small illustrated, abstract AI companion (not a likeness of any real person).
 * Pure SVG + CSS animation: floating motion, glowing core, blinking eye, orbiting particles.
 */
const AIAvatar = () => {
  const [blink, setBlink] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setBlink(true);
      setTimeout(() => setBlink(false), 180);
    }, 3200 + Math.random() * 1800);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="ai-avatar-float relative h-full w-full flex items-center justify-center">
      <svg
        viewBox="0 0 240 240"
        className="h-full w-full"
        style={{ filter: 'drop-shadow(0 0 24px rgba(120, 200, 255, 0.35))' }}
      >
        <defs>
          <radialGradient id="coreGlow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#9fe6ff" stopOpacity="0.9" />
            <stop offset="60%" stopColor="#4fb6e8" stopOpacity="0.4" />
            <stop offset="100%" stopColor="#4fb6e8" stopOpacity="0" />
          </radialGradient>
          <linearGradient id="bodyGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#2a2f3a" />
            <stop offset="100%" stopColor="#15171d" />
          </linearGradient>
          <linearGradient id="headGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#3a4150" />
            <stop offset="100%" stopColor="#21242c" />
          </linearGradient>
        </defs>

        {/* Orbiting particles */}
        <g className="ai-avatar-orbit" style={{ transformOrigin: '120px 110px' }}>
          <circle cx="120" cy="28" r="3.5" fill="#9fe6ff" opacity="0.8" />
        </g>
        <g className="ai-avatar-orbit-rev" style={{ transformOrigin: '120px 110px' }}>
          <circle cx="120" cy="194" r="2.5" fill="#7dd3fc" opacity="0.6" />
        </g>

        {/* Antenna */}
        <line x1="120" y1="40" x2="120" y2="58" stroke="#5a6275" strokeWidth="3" strokeLinecap="round" />
        <circle cx="120" cy="36" r="6" fill="url(#coreGlow)" />
        <circle cx="120" cy="36" r="3" fill="#cdf4ff" className="ai-avatar-pulse" />

        {/* Head */}
        <rect x="70" y="58" width="100" height="84" rx="28" fill="url(#headGrad)" stroke="#4a5163" strokeWidth="1.5" />

        {/* Face screen */}
        <rect x="84" y="76" width="72" height="48" rx="16" fill="#0c1117" />

        {/* Eyes */}
        <g>
          <ellipse
            cx="106"
            cy="100"
            rx="8"
            ry={blink ? 1 : 9}
            fill="#7fe3ff"
            className="ai-avatar-eye-glow"
            style={{ transition: 'ry 0.12s ease' }}
          />
          <ellipse
            cx="134"
            cy="100"
            rx="8"
            ry={blink ? 1 : 9}
            fill="#7fe3ff"
            className="ai-avatar-eye-glow"
            style={{ transition: 'ry 0.12s ease' }}
          />
        </g>

        {/* Cheek vents */}
        <circle cx="76" cy="118" r="2.5" fill="#3a4150" />
        <circle cx="164" cy="118" r="2.5" fill="#3a4150" />

        {/* Neck joint */}
        <rect x="110" y="142" width="20" height="10" rx="4" fill="#3a4150" />

        {/* Body */}
        <path
          d="M 60 152 Q 60 148 64 148 L 176 148 Q 180 148 180 152 L 186 206 Q 187 214 179 214 L 61 214 Q 53 214 54 206 Z"
          fill="url(#bodyGrad)"
          stroke="#4a5163"
          strokeWidth="1.5"
        />

        {/* Chest core */}
        <circle cx="120" cy="180" r="18" fill="url(#coreGlow)" />
        <circle cx="120" cy="180" r="9" fill="#bdf0ff" className="ai-avatar-pulse" />
        <circle cx="120" cy="180" r="9" fill="none" stroke="#eafcff" strokeWidth="1.5" opacity="0.6" />

        {/* Shoulder lights */}
        <circle cx="74" cy="160" r="3" fill="#5fd4ff" opacity="0.7" className="ai-avatar-pulse-delay" />
        <circle cx="166" cy="160" r="3" fill="#5fd4ff" opacity="0.7" className="ai-avatar-pulse-delay" />
      </svg>

      <style>{`
        .ai-avatar-float {
          animation: aiAvatarFloat 4.5s ease-in-out infinite;
        }
        @keyframes aiAvatarFloat {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-14px); }
        }
        .ai-avatar-pulse {
          animation: aiAvatarPulse 2.2s ease-in-out infinite;
        }
        .ai-avatar-pulse-delay {
          animation: aiAvatarPulse 2.2s ease-in-out infinite;
          animation-delay: 0.6s;
        }
        @keyframes aiAvatarPulse {
          0%, 100% { opacity: 0.6; }
          50% { opacity: 1; }
        }
        .ai-avatar-eye-glow {
          animation: aiAvatarEyeGlow 2.6s ease-in-out infinite;
        }
        @keyframes aiAvatarEyeGlow {
          0%, 100% { filter: drop-shadow(0 0 2px #7fe3ff); }
          50% { filter: drop-shadow(0 0 7px #7fe3ff); }
        }
        .ai-avatar-orbit {
          animation: aiAvatarOrbit 6s linear infinite;
        }
        .ai-avatar-orbit-rev {
          animation: aiAvatarOrbitRev 8s linear infinite;
        }
        @keyframes aiAvatarOrbit {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        @keyframes aiAvatarOrbitRev {
          from { transform: rotate(360deg); }
          to { transform: rotate(0deg); }
        }
      `}</style>
    </div>
  );
};

export default AIAvatar;
