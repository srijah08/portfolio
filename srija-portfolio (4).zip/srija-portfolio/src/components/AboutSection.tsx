import FadeIn from './FadeIn';
import ContactButton from './ContactButton';
import AnimatedText from './AnimatedText';

const ABOUT_TEXT =
  "I'm an Electronics and Communication Engineer from Nagarjuna College of Engineering and Technology, currently building a live electoral management system for the State Election Commission of Karnataka. I enjoy working across the stack — from CNN-based disease detection for arecanut farming to hardware-level research at DRDO — and I'm driven by curiosity, clean problem-solving, and shipping things that actually get used. Let's build something incredible together!";

const SKILL_GROUPS = [
  { label: 'Languages', items: ['Python', 'JavaScript'] },
  { label: 'Web', items: ['HTML', 'CSS', 'JavaScript'] },
  { label: 'Domains', items: ['VLSI', 'Electronics Mfg.', 'AI/ML'] },
  { label: 'Tools', items: ['Git', 'GitHub'] },
];

const AboutSection = () => {
  return (
    <section
      id="about"
      className="relative flex min-h-screen w-full items-center justify-center overflow-hidden bg-void px-5 sm:px-8 md:px-10 py-20 font-display"
    >
      {/* faint circuit grid backdrop */}
      <div className="absolute inset-0 about-grid opacity-[0.05] pointer-events-none" />
      <div className="absolute right-[6%] top-[12%] h-72 w-72 rounded-full about-glow blur-3xl pointer-events-none" />

      {/* Center content */}
      <div className="relative z-10 flex flex-col items-center gap-10 sm:gap-14 md:gap-16 text-center">
        <FadeIn delay={0} y={40}>
          <p className="font-mono text-[10px] sm:text-xs uppercase tracking-[0.35em] text-signal/70 mb-3">
            01 / Profile
          </p>
          <h2
            className="hero-heading font-semibold uppercase leading-none tracking-tight"
            style={{ fontSize: 'clamp(3rem, 12vw, 160px)' }}
          >
            About me
          </h2>
        </FadeIn>

          <div className="flex flex-col items-center gap-12 sm:gap-16 md:gap-20">
                    <AnimatedText
                      text={ABOUT_TEXT}
                      className="font-medium leading-relaxed text-[#D7E2EA] max-w-[560px] font-body"
                      style={{ fontSize: 'clamp(1rem, 2vw, 1.35rem)' }}
                    />

                    {/* Skills */}
                    <FadeIn delay={0.15} className="w-full max-w-3xl">
                      <div className="flex flex-col gap-5 sm:gap-6">
                        {SKILL_GROUPS.map((group) => (
                          <div
                            key={group.label}
                            className="flex flex-col sm:flex-row sm:items-baseline gap-2 sm:gap-5"
                          >
                            <span className="font-mono text-[10px] uppercase tracking-widest text-signal/50 sm:w-32 sm:shrink-0 sm:text-right">
                              {group.label}
                            </span>
                            <div className="flex flex-wrap gap-2">
                              {group.items.map((item) => (
                                <span
                                  key={item}
                                  className="skill-chip rounded border border-signal/15 bg-signal/[0.03] px-3 py-1 font-mono text-sm text-[#D7E2EA]/80 transition-all"
                                >
                                  {item}
                                </span>
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>
                    </FadeIn>

                    <FadeIn delay={0.25}>
                      <ContactButton />
                    </FadeIn>
                  </div>
      </div>

      <style>{`
        .about-grid {
          background-image:
            linear-gradient(rgba(159, 230, 255, 0.5) 1px, transparent 1px),
            linear-gradient(90deg, rgba(159, 230, 255, 0.5) 1px, transparent 1px);
          background-size: 56px 56px;
        }
        .about-glow {
          background: radial-gradient(circle, rgba(124, 92, 255, 0.25), transparent 70%);
        }
        .skill-chip:hover {
          border-color: rgba(159, 230, 255, 0.5);
          background: rgba(159, 230, 255, 0.08);
          color: #EAF4FF;
          transform: translateY(-2px);
        }
      `}</style>
    </section>
  );
};

export default AboutSection;
