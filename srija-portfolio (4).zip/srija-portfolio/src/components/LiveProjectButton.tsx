interface LiveProjectButtonProps {
  label?: string;
  href?: string;
  className?: string;
}

const LiveProjectButton = ({
  label = 'Live Project',
  href = '#',
  className = '',
}: LiveProjectButtonProps) => {
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className={`inline-flex items-center justify-center rounded-md border border-signal/50 px-8 py-3 sm:px-10 sm:py-3.5 font-mono text-xs sm:text-sm font-medium uppercase tracking-widest text-signal whitespace-nowrap transition-all duration-200 hover:bg-signal/10 hover:border-signal hover:shadow-[0_0_20px_rgba(159,230,255,0.3)] ${className}`}
    >
      {label}
    </a>
  );
};

export default LiveProjectButton;
